<?php

wa('webasyst');
class siteFrontendRegionsController extends webasystBackendRegionsController
{

}