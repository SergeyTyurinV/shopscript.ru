<?php

class sitePlugin extends waPlugin {

}