<?php

class waContactDataTextModel extends waContactDataModel
{
    protected $table = "wa_contact_data_text";
}
