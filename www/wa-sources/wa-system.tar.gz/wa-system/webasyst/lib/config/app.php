<?php

return array(
    'name' => 'Webasyst',
    'prefix' => 'webasyst',
    'version' => '1.7.15',
    'critical'=>'1.7.15',
    'vendor' => 'webasyst',
);
