<?php

return array(
    'code' => 'MGA',
    'sign' => 'Ar',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Malagasy ariary',
    'name' => array(
        'ariary',
    ),
    'frac_name' => array(
        'iraimbilanja'
    )
);
