<?php

return array(
    'code' => 'TJS',
    'sign' => 'somoni',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Tajikistani somoni',
    'name' => array(
        'somoni',
    ),
    'frac_name' => array(
        'diram',
    )
);