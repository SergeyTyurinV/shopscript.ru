<?php

return array(
    'code' => 'UZS',
    'sign' => 'sum',
    'sign_position' => null,
    'sign_delim' => null,
    'title' => 'Uzbekistan sum',
    'name' => array(
        'sum',
    ),
    'frac_name' => array(
        'tiyin',
    )
);