<?php

return array(
    'code' => 'ARS',
    'sign' => '$',
    'sign_position' => 0,
    'sign_delim' => '',
    'title' => 'Argentine peso',
    'name' => array(
        array('peso', 'pesos'),
    ),
    'frac_name' => array(
        array('centavo', 'centavos'),
    )
);